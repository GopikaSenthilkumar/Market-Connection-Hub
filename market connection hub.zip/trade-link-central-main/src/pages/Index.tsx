
import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Features } from '@/components/Features';
import { CompanyGrid } from '@/components/CompanyGrid';
import { Footer } from '@/components/Footer';
import { mockCompanies } from '@/data/mockData';

const Index = () => {
  const featuredCompanies = mockCompanies.slice(0, 6);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <Hero />
      <Features />
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Featured Companies</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover some of the top businesses in our network and explore potential collaboration opportunities.
            </p>
          </div>
          
          <CompanyGrid companies={featuredCompanies} />
          
          <div className="text-center mt-12">
            <a 
              href="/companies" 
              className="inline-flex items-center text-market-blue hover:text-market-darkBlue font-semibold"
            >
              View all companies
              <svg
                className="ml-2 h-5 w-5"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z"
                  clipRule="evenodd"
                />
              </svg>
            </a>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Expand Your Network?</h2>
            <p className="text-gray-600 mb-8">
              Join thousands of businesses already connecting and growing through Market-Connection-Hub.
            </p>
            <button className="bg-gradient-to-r from-market-blue to-market-darkBlue hover:from-market-darkBlue hover:to-market-blue text-white px-8 py-3 rounded-md font-semibold">
              Get Started Today
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
