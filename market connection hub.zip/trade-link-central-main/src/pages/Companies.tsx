
import React from 'react';
import { Navbar } from '@/components/Navbar';
import { CompanyGrid } from '@/components/CompanyGrid';
import { Footer } from '@/components/Footer';
import { mockCompanies } from '@/data/mockData';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

const Companies = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">Explore Companies</h1>
            <div className="relative mb-8">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input 
                placeholder="Search by company name, location, or industry..." 
                className="pl-10 py-6 bg-white"
              />
            </div>
            
            <CompanyGrid companies={mockCompanies} />
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Companies;
