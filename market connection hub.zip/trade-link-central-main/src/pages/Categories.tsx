
import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { mockCompanies } from '@/data/mockData';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Building2, 
  Briefcase, 
  FileText, 
  Activity, 
  Truck, 
  ShieldCheck, 
  Globe, 
  ShoppingBag 
} from 'lucide-react';

const Categories = () => {
  // Extract unique categories
  const categories = Array.from(new Set(mockCompanies.map(company => company.category)));
  
  // Count companies per category
  const categoryCounts = categories.reduce((acc, category) => {
    acc[category] = mockCompanies.filter(company => company.category === category).length;
    return acc;
  }, {} as Record<string, number>);
  
  // Icon mapping
  const getCategoryIcon = (category: string) => {
    const iconMap: Record<string, React.ReactNode> = {
      'Technology': <Building2 className="h-10 w-10" />,
      'Energy': <Activity className="h-10 w-10" />,
      'Healthcare': <ShieldCheck className="h-10 w-10" />,
      'Finance': <Briefcase className="h-10 w-10" />,
      'Manufacturing': <FileText className="h-10 w-10" />,
      'Logistics': <Truck className="h-10 w-10" />,
      'Agriculture': <Globe className="h-10 w-10" />,
      'Media': <ShoppingBag className="h-10 w-10" />,
    };
    
    return iconMap[category] || <Building2 className="h-10 w-10" />;
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-3xl font-bold mb-6">Browse by Industry</h1>
            <p className="text-gray-600 mb-8">
              Explore companies across different industries and find the right connections for your business needs.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((category) => (
                <a 
                  key={category} 
                  href={`/companies?category=${category}`} 
                  className="no-underline"
                >
                  <Card className="hover:shadow-md transition-shadow duration-300 h-full">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="w-16 h-16 rounded-full bg-market-blue/10 flex items-center justify-center mb-4 text-market-blue">
                        {getCategoryIcon(category)}
                      </div>
                      <h3 className="text-xl font-semibold mb-2">{category}</h3>
                      <p className="text-gray-500">{categoryCounts[category]} companies</p>
                    </CardContent>
                  </Card>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Categories;
