
import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Check } from 'lucide-react';

const About = () => {
  const teamMembers = [
    {
      name: 'Jennifer Chen',
      position: 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop'
    },
    {
      name: 'Michael Rodriguez',
      position: 'CTO',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=200&auto=format&fit=crop'
    },
    {
      name: 'Sarah Johnson',
      position: 'Chief Marketing Officer',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200&auto=format&fit=crop'
    },
    {
      name: 'David Kim',
      position: 'Head of Global Relations',
      image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=200&auto=format&fit=crop'
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <section className="py-12 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">About Market-Connection-Hub</h1>
            <p className="text-lg text-gray-600 mb-8">
              We're on a mission to break down barriers between businesses and create meaningful connections across borders and industries.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-market-blue mb-2">2021</div>
                  <p className="text-gray-600">Year Founded</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-market-blue mb-2">45+</div>
                  <p className="text-gray-600">Team Members</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-market-blue mb-2">120K+</div>
                  <p className="text-gray-600">Connections Made</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-4">Our Story</h2>
              <p className="text-gray-600 mb-4">
                Market-Connection-Hub was founded in 2021 by a team of international business experts who recognized the challenges that companies face when trying to expand into new markets or find reliable partners abroad.
              </p>
              <p className="text-gray-600">
                What started as a small directory of vetted businesses has grown into a comprehensive platform that facilitates meaningful connections between companies of all sizes across the globe. Our platform combines cutting-edge technology with human expertise to ensure that businesses can find exactly what they need to grow and thrive.
              </p>
            </div>
            
            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6">Our Values</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <div className="flex items-start">
                  <div className="mt-1 mr-3 flex-shrink-0">
                    <Check className="h-5 w-5 text-market-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Trust & Transparency</h3>
                    <p className="text-gray-600 text-sm">We verify all businesses on our platform and promote honest, open communication.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-3 flex-shrink-0">
                    <Check className="h-5 w-5 text-market-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Global Perspective</h3>
                    <p className="text-gray-600 text-sm">We embrace diversity and build bridges between different markets and cultures.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-3 flex-shrink-0">
                    <Check className="h-5 w-5 text-market-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Innovation</h3>
                    <p className="text-gray-600 text-sm">We continuously improve our platform to better serve the evolving needs of businesses.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-3 flex-shrink-0">
                    <Check className="h-5 w-5 text-market-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Meaningful Connections</h3>
                    <p className="text-gray-600 text-sm">We focus on quality over quantity, helping businesses form lasting, valuable relationships.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-8 text-center">Our Leadership Team</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <div key={index} className="text-center">
                  <div className="w-32 h-32 rounded-full overflow-hidden mx-auto mb-4">
                    <img 
                      src={member.image} 
                      alt={member.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold">{member.name}</h3>
                  <p className="text-gray-600 text-sm">{member.position}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default About;
