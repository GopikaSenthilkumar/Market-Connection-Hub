
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Search, Menu } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-mobile';

export function Navbar() {
  const isMobile = useIsMobile();

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="container flex items-center justify-between h-16 px-4 mx-auto">
        <div className="flex items-center">
          <Link to="/" className="flex items-center gap-2">
            <div className="rounded-md bg-gradient-to-r from-market-blue to-market-darkBlue p-1.5">
              <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
                <div className="w-4 h-4 bg-gradient-to-r from-market-blue to-market-darkBlue rounded-sm"></div>
              </div>
            </div>
            <span className="text-xl font-bold hidden md:inline">Market-Connection-Hub</span>
            <span className="text-xl font-bold md:hidden">MCH</span>
          </Link>
        </div>

        {!isMobile && (
          <div className="flex items-center px-2 mx-4 flex-1 max-w-md">
            <div className="relative w-full">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search companies, services..."
                className="w-full pl-8 pr-4 py-2 bg-gray-50"
              />
            </div>
          </div>
        )}

        <div className="flex items-center gap-4">
          {isMobile ? (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="mt-6 flex flex-col gap-4">
                  <div className="relative w-full">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search companies, services..."
                      className="w-full pl-8 pr-4 py-2 bg-gray-50"
                    />
                  </div>
                  <Link to="/companies">
                    <Button variant="outline" className="w-full justify-start">Companies</Button>
                  </Link>
                  <Link to="/categories">
                    <Button variant="outline" className="w-full justify-start">Categories</Button>
                  </Link>
                  <Link to="/about">
                    <Button variant="outline" className="w-full justify-start">About</Button>
                  </Link>
                  <Button className="w-full bg-gradient-to-r from-market-blue to-market-darkBlue hover:from-market-darkBlue hover:to-market-blue">Join Now</Button>
                </div>
              </SheetContent>
            </Sheet>
          ) : (
            <>
              <Link to="/companies">
                <Button variant="ghost">Companies</Button>
              </Link>
              <Link to="/categories">
                <Button variant="ghost">Categories</Button>
              </Link>
              <Link to="/about">
                <Button variant="ghost">About</Button>
              </Link>
              <Button className="bg-gradient-to-r from-market-blue to-market-darkBlue hover:from-market-darkBlue hover:to-market-blue">Join Now</Button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
