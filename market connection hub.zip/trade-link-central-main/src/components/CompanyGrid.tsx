
import React, { useState } from 'react';
import { CompanyCard, Company } from './CompanyCard';
import { CategoryFilter } from './CategoryFilter';

interface CompanyGridProps {
  companies: Company[];
}

export function CompanyGrid({ companies }: CompanyGridProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  
  // Extract unique categories from companies
  const allCategories = Array.from(new Set(companies.map(company => company.category)));
  
  const handleCategorySelect = (category: string) => {
    setSelectedCategories(prev => 
      prev.includes(category) 
        ? prev.filter(c => c !== category) 
        : [...prev, category]
    );
  };
  
  // Filter companies based on selected categories
  const filteredCompanies = selectedCategories.length > 0
    ? companies.filter(company => selectedCategories.includes(company.category))
    : companies;
  
  return (
    <div>
      <CategoryFilter 
        categories={allCategories}
        selectedCategories={selectedCategories}
        onSelectCategory={handleCategorySelect}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCompanies.map(company => (
          <CompanyCard key={company.id} company={company} />
        ))}
      </div>
    </div>
  );
}
