
import React from 'react';
import { Check, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface CategoryFilterProps {
  categories: string[];
  selectedCategories: string[];
  onSelectCategory: (category: string) => void;
}

export function CategoryFilter({ 
  categories, 
  selectedCategories, 
  onSelectCategory 
}: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2 mb-6">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="bg-white">
            Industry
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56 bg-white">
          <DropdownMenuGroup>
            {categories.map((category) => (
              <DropdownMenuItem 
                key={category} 
                onClick={() => onSelectCategory(category)}
                className="flex items-center justify-between"
              >
                {category}
                {selectedCategories.includes(category) && (
                  <Check className="h-4 w-4 text-market-blue" />
                )}
              </DropdownMenuItem>
            ))}
          </DropdownMenuGroup>
        </DropdownMenuContent>
      </DropdownMenu>
      
      {selectedCategories.map((category) => (
        <Badge 
          key={category} 
          variant="secondary"
          className="bg-market-lightGray text-market-darkGray hover:bg-gray-200"
          onClick={() => onSelectCategory(category)}
        >
          {category}
          <span className="ml-1 cursor-pointer">×</span>
        </Badge>
      ))}
    </div>
  );
}
