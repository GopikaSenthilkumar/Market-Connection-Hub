
import React from 'react';
import { Building2, MapPin, Users, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';

export interface Company {
  id: number;
  name: string;
  logo: string;
  location: string;
  category: string;
  description: string;
  employeeCount: string;
  websiteUrl: string;
}

interface CompanyCardProps {
  company: Company;
}

export function CompanyCard({ company }: CompanyCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md animate-scale-in">
      <CardHeader className="p-4 pb-0 flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded bg-gray-100 flex items-center justify-center overflow-hidden">
            {company.logo ? (
              <img src={company.logo} alt={`${company.name} logo`} className="w-full h-full object-contain" />
            ) : (
              <Building2 className="h-6 w-6 text-gray-400" />
            )}
          </div>
          <div>
            <h3 className="font-semibold text-lg">{company.name}</h3>
            <div className="flex items-center text-sm text-gray-500">
              <MapPin className="h-3.5 w-3.5 mr-1" />
              {company.location}
            </div>
          </div>
        </div>
        <Badge className="bg-market-lightGray text-market-darkGray hover:bg-gray-200">
          {company.category}
        </Badge>
      </CardHeader>
      <CardContent className="p-4">
        <p className="text-gray-600 text-sm line-clamp-3">
          {company.description}
        </p>
        <div className="flex items-center mt-3 text-sm text-gray-500">
          <Users className="h-4 w-4 mr-1" />
          <span>{company.employeeCount} employees</span>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <Button variant="outline" size="sm" className="text-market-blue border-market-blue hover:bg-market-blue/10">
          Connect
        </Button>
        <a 
          href={company.websiteUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center text-sm text-gray-500 hover:text-market-darkBlue"
        >
          Visit Website <ExternalLink className="ml-1 h-3.5 w-3.5" />
        </a>
      </CardFooter>
    </Card>
  );
}
