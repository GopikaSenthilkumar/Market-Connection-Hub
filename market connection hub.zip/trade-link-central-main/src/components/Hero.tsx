
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative bg-gradient-to-b from-white to-gray-50 py-20 md:py-28">
      <div className="container px-4 mx-auto">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Connect Your Business to <span className="bg-clip-text text-transparent bg-gradient-to-r from-market-blue to-market-darkBlue">Global Markets</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-8 md:mb-10">
            The premier platform for businesses to discover partners, suppliers, and new opportunities across industries and borders.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-gradient-to-r from-market-blue to-market-darkBlue hover:from-market-darkBlue hover:to-market-blue text-white px-8 py-6 h-auto text-lg">
              Explore Companies
            </Button>
            <Button variant="outline" className="px-8 py-6 h-auto text-lg">
              Learn More
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Stats section */}
      <div className="container mx-auto mt-20">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <p className="text-3xl md:text-4xl font-bold text-market-darkBlue">5000+</p>
            <p className="text-gray-600">Companies</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <p className="text-3xl md:text-4xl font-bold text-market-darkBlue">120+</p>
            <p className="text-gray-600">Countries</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <p className="text-3xl md:text-4xl font-bold text-market-darkBlue">50+</p>
            <p className="text-gray-600">Industries</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm text-center">
            <p className="text-3xl md:text-4xl font-bold text-market-darkBlue">10k+</p>
            <p className="text-gray-600">Connections</p>
          </div>
        </div>
      </div>
    </div>
  );
}
