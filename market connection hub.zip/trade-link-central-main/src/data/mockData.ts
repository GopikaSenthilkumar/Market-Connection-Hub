
import { Company } from '../components/CompanyCard';

export const mockCompanies: Company[] = [
  {
    id: 1,
    name: 'TechGlobal Solutions',
    logo: '',
    location: 'San Francisco, USA',
    category: 'Technology',
    description: 'Leading provider of enterprise software solutions with specialization in cloud infrastructure, data analytics, and cybersecurity services for Fortune 500 companies.',
    employeeCount: '1000-5000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 2,
    name: 'GreenEnergy Innovations',
    logo: '',
    location: 'Berlin, Germany',
    category: 'Energy',
    description: 'Developing cutting-edge renewable energy technologies focused on solar, wind, and hydroelectric power solutions for residential and commercial applications.',
    employeeCount: '500-1000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 3,
    name: 'MediCare Health',
    logo: '',
    location: 'London, UK',
    category: 'Healthcare',
    description: 'Pioneering healthcare provider offering innovative medical devices, telemedicine platforms, and pharmaceutical research services globally.',
    employeeCount: '5000+',
    websiteUrl: 'https://example.com'
  },
  {
    id: 4,
    name: 'FinTech Innovations',
    logo: '',
    location: 'Singapore',
    category: 'Finance',
    description: 'Financial technology company specializing in blockchain solutions, digital payment systems, and automated trading platforms for institutional clients.',
    employeeCount: '100-500',
    websiteUrl: 'https://example.com'
  },
  {
    id: 5,
    name: 'EcoFriendly Materials',
    logo: '',
    location: 'Stockholm, Sweden',
    category: 'Manufacturing',
    description: 'Manufacturer of sustainable materials and biodegradable alternatives to plastic products, serving packaging and consumer goods industries.',
    employeeCount: '100-500',
    websiteUrl: 'https://example.com'
  },
  {
    id: 6,
    name: 'Global Logistics Partners',
    logo: '',
    location: 'Dubai, UAE',
    category: 'Logistics',
    description: 'International logistics provider offering comprehensive supply chain solutions, freight forwarding, and customs clearance services across 75 countries.',
    employeeCount: '1000-5000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 7,
    name: 'Agritech Solutions',
    logo: '',
    location: 'Sao Paulo, Brazil',
    category: 'Agriculture',
    description: 'Agricultural technology company developing irrigation systems, crop monitoring tools, and precision farming equipment for sustainable agriculture.',
    employeeCount: '100-500',
    websiteUrl: 'https://example.com'
  },
  {
    id: 8,
    name: 'Creative Media Group',
    logo: '',
    location: 'Toronto, Canada',
    category: 'Media',
    description: 'Full-service media company providing content creation, digital marketing, and advertising solutions for brands looking to enhance their market presence.',
    employeeCount: '100-500',
    websiteUrl: 'https://example.com'
  },
  {
    id: 9,
    name: 'SmartHome Devices',
    logo: '',
    location: 'Seoul, South Korea',
    category: 'Technology',
    description: 'Designer and manufacturer of IoT-enabled smart home devices and systems featuring AI integration for residential and commercial building automation.',
    employeeCount: '500-1000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 10,
    name: 'Advanced Materials Inc',
    logo: '',
    location: 'Tokyo, Japan',
    category: 'Manufacturing',
    description: 'Pioneering research and manufacturing company specialized in advanced composite materials, nano-materials, and high-performance polymers.',
    employeeCount: '1000-5000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 11,
    name: 'Oceanic Shipping',
    logo: '',
    location: 'Rotterdam, Netherlands',
    category: 'Logistics',
    description: 'Maritime logistics company operating a fleet of container ships and providing international shipping services across major global trade routes.',
    employeeCount: '500-1000',
    websiteUrl: 'https://example.com'
  },
  {
    id: 12,
    name: 'Diamond Investment Group',
    logo: '',
    location: 'Johannesburg, South Africa',
    category: 'Finance',
    description: 'Financial services firm specializing in investment management, wealth advisory, and commodity trading with a focus on emerging markets.',
    employeeCount: '100-500',
    websiteUrl: 'https://example.com'
  }
];
